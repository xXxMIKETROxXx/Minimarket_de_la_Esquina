const productosIniciales = [
    { codigo: "PRD-001", id: "leche", nombre: "Leche entera 1 litro", descripcion: "Leche entera para el consumo diario.", precio: 1190, stock: 25, critico: 5, categoria: "Lácteos", imagen: "leche.svg" },
    { codigo: "PRD-002", id: "pan", nombre: "Pan fresco", descripcion: "Pan fresco para acompañar tus comidas.", precio: 1500, stock: 18, critico: 4, categoria: "Panadería", imagen: "pan.svg" },
    { codigo: "PRD-003", id: "bebida", nombre: "Bebida gaseosa 1.5 litros", descripcion: "Bebida para compartir en familia.", precio: 2190, stock: 12, critico: 3, categoria: "Bebidas", imagen: "bebida.svg" },
    { codigo: "PRD-004", id: "galletas", nombre: "Galletas de chocolate", descripcion: "Galletas dulces para cualquier momento.", precio: 890, stock: 20, critico: 5, categoria: "Galletas", imagen: "galletas.svg" },
    { codigo: "PRD-005", id: "arroz", nombre: "Arroz grano largo 1 kg", descripcion: "Arroz grano largo para preparar tus comidas.", precio: 1590, stock: 32, critico: 8, categoria: "Abarrotes", imagen: "arroz.svg" },
    { codigo: "PRD-006", id: "fideos", nombre: "Fideos spaghetti 400 g", descripcion: "Fideos para una comida rápida y rica.", precio: 790, stock: 24, critico: 6, categoria: "Abarrotes", imagen: "fideos.svg" },
    { codigo: "PRD-007", id: "snacks", nombre: "Snack de papas", descripcion: "Snack salado para compartir.", precio: 990, stock: 15, critico: 4, categoria: "Snacks", imagen: "snacks.svg" },
    { codigo: "PRD-008", id: "limpieza", nombre: "Detergente líquido 1 litro", descripcion: "Detergente para la limpieza del hogar.", precio: 2490, stock: 10, critico: 3, categoria: "Limpieza", imagen: "limpieza.svg" }
];

const regiones = {
    metropolitana: ["Santiago", "Maipú", "Providencia"],
    valparaiso: ["Valparaíso", "Viña del Mar", "Quilpué"],
    ohiggins: ["Rancagua", "Machalí", "San Fernando"]
};

function obtenerUsuarios() {
    let usuarios = JSON.parse(localStorage.getItem("usuarios"));
    if (!usuarios) {
        usuarios = [];
    }
    let administrador = usuarios.find(function(usuario) { return usuario.correo === "admin@duoc.cl"; });
    if (!administrador) {
        usuarios.push({ run: "190110222", nombre: "Administrador", apellidos: "La Esquina", correo: "admin@duoc.cl", password: "admin1", tipo: "Administrador", region: "metropolitana", comuna: "santiago", direccion: "Calle Principal 1" });
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
    }
    return usuarios;
}

function obtenerProductos() {
    let productos = JSON.parse(localStorage.getItem("productos"));
    if (!productos) {
        productos = productosIniciales;
        localStorage.setItem("productos", JSON.stringify(productos));
    }
    return productos;
}

function formatoPrecio(precio) {
    return "$" + Number(precio).toLocaleString("es-CL");
}

function mostrarProductosTienda() {
    let contenedor = document.getElementById("lista-productos");
    if (!contenedor) return;
    let productos = obtenerProductos();
    contenedor.innerHTML = "";
    for (let i = 0; i < productos.length; i++) {
        let producto = productos[i];
        let articulo = document.createElement("article");
        articulo.innerHTML = "<img src='../img/" + producto.imagen + "' alt='" + producto.nombre + "'><h2>" + producto.nombre + "</h2><p>" + formatoPrecio(producto.precio) + "</p><a href='detalle-producto.html?producto=" + producto.id + "'>Ver detalle</a>";
        contenedor.appendChild(articulo);
    }
}

function cargarDetalle() {
    let contenedor = document.getElementById("detalle-producto");
    if (!contenedor) return;
    let id = new URLSearchParams(window.location.search).get("producto") || "leche";
    let producto = obtenerProductos().find(function(item) { return item.id === id; }) || obtenerProductos()[0];
    contenedor.innerHTML = "<img src='../img/" + producto.imagen + "' alt='" + producto.nombre + "'><h1>" + producto.nombre + "</h1><p>" + producto.descripcion + "</p><p>Precio: " + formatoPrecio(producto.precio) + "</p><p>Stock: " + producto.stock + " unidades</p><p>Categoría: " + producto.categoria + "</p>";
}

function cargarComunas() {
    let region = document.getElementById("region");
    let comuna = document.getElementById("comuna");
    if (!region || !comuna) return;
    comuna.innerHTML = "";
    let lista = regiones[region.value] || [];
    for (let i = 0; i < lista.length; i++) {
        let opcion = document.createElement("option");
        opcion.value = lista[i].toLowerCase().replaceAll(" ", "-");
        opcion.textContent = lista[i];
        comuna.appendChild(opcion);
    }
}

function validarRun(run) {
    if (!/^[0-9]{7,8}[0-9kK]$/.test(run)) return false;
    let numero = run.substring(0, run.length - 1);
    let digito = run.substring(run.length - 1).toLowerCase();
    let suma = 0;
    let multiplicador = 2;
    for (let i = numero.length - 1; i >= 0; i--) {
        suma += Number(numero[i]) * multiplicador;
        multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
    }
    let resto = 11 - (suma % 11);
    let verificador = resto === 11 ? "0" : resto === 10 ? "k" : String(resto);
    return digito === verificador;
}

function validarCorreo(correo) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);
}

function validarDominioCorreo(correo) {
    return /@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/i.test(correo);
}

function mostrarAvisoCampo(campo, texto) {
    let aviso = document.getElementById("aviso-" + campo.id);
    if (aviso) aviso.textContent = texto;
}

function conectarValidacionTiempoReal() {
    let correo = document.getElementById("correo");
    if (correo) {
        correo.addEventListener("blur", function() {
            if (validarCorreo(correo.value) && validarDominioCorreo(correo.value)) {
                mostrarAvisoCampo(correo, "Correo válido.");
            } else {
                mostrarAvisoCampo(correo, "Usa @duoc.cl, @profesor.duoc.cl o @gmail.com.");
            }
        });
    }
    let password = document.getElementById("password");
    if (password) {
        password.addEventListener("input", function() {
            mostrarAvisoCampo(password, password.value.length >= 4 && password.value.length <= 10 ? "Contraseña válida." : "Debe tener entre 4 y 10 caracteres.");
        });
    }
    let run = document.getElementById("run");
    if (run) {
        run.addEventListener("input", function() {
            mostrarAvisoCampo(run, validarRun(run.value) ? "RUN válido." : "Escribe entre 7 y 9 caracteres, sin puntos ni guion.");
        });
    }
}

function protegerAdministracion() {
    if (!document.body.classList.contains("administracion")) return;
    let usuarioActivo = JSON.parse(localStorage.getItem("usuarioActivo"));
    if (!usuarioActivo || usuarioActivo.tipo !== "Administrador") {
        document.body.innerHTML = "<main><section><h1>Acceso restringido</h1><p>Se requiere acceso de administrador para entrar aquí.</p><a href='../tienda/login.html'>Ir al inicio de sesión</a></section></main>";
    }
}

function conectarFormularioRegistro() {
    let formulario = document.getElementById("form-registro");
    if (!formulario) return;
    formulario.addEventListener("submit", function(evento) {
        evento.preventDefault();
        let mensaje = document.getElementById("mensaje-registro");
        let datos = new FormData(formulario);
        let contraseña = datos.get("password");
        if (!validarRun(datos.get("run"))) {
            mensaje.textContent = "El RUN no es válido. Usa entre 7 y 9 caracteres, por ejemplo 19011022K.";
            mensaje.className = "mensaje error";
            return;
        }
        if (!validarCorreo(datos.get("correo")) || !validarDominioCorreo(datos.get("correo"))) {
            mensaje.textContent = "Escribe un correo válido de @duoc.cl, @profesor.duoc.cl o @gmail.com.";
            mensaje.className = "mensaje error";
            return;
        }
        if (contraseña.length < 4 || contraseña.length > 10) {
            mensaje.textContent = "La contraseña debe tener entre 4 y 10 caracteres.";
            mensaje.className = "mensaje error";
            return;
        }
        let usuarios = obtenerUsuarios();
        let usuarioExistente = usuarios.find(function(usuario) { return usuario.correo === datos.get("correo") || usuario.run === datos.get("run"); });
        if (usuarioExistente) {
            mensaje.textContent = "El RUN o el correo ya están registrados.";
            mensaje.className = "mensaje error";
            return;
        }
        datos.set("tipo", "Cliente");
        usuarios.push(Object.fromEntries(datos.entries()));
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
        mensaje.textContent = "Registro realizado correctamente.";
        mensaje.className = "mensaje correcto";
        formulario.reset();
    });
}

function conectarFormularioLogin() {
    let formulario = document.getElementById("form-login");
    if (!formulario) return;
    formulario.addEventListener("submit", function(evento) {
        evento.preventDefault();
        let correo = document.getElementById("correo").value;
        let contraseña = document.getElementById("password").value;
        let usuarios = obtenerUsuarios();
        let encontrado = usuarios.find(function(usuario) { return usuario.correo === correo && usuario.password === contraseña; });
        let mensaje = document.getElementById("mensaje-login");
        if (encontrado) {
            localStorage.setItem("usuarioActivo", JSON.stringify(encontrado));
            mensaje.textContent = "Inicio de sesión correcto. Rol: " + (encontrado.tipo || "Cliente") + ".";
            if (encontrado.tipo === "Administrador") {
                window.location.href = "../admin/index.html";
                return;
            }
        } else {
            mensaje.textContent = "Correo o contraseña incorrectos.";
        }
        mensaje.className = encontrado ? "mensaje correcto" : "mensaje error";
    });
}

function conectarFormularioContacto() {
    let formulario = document.getElementById("form-contacto");
    if (!formulario) return;
    formulario.addEventListener("submit", function(evento) {
        evento.preventDefault();
        let correo = document.getElementById("correo").value;
        let mensaje = document.getElementById("mensaje-contacto");
        mensaje.textContent = validarCorreo(correo) && validarDominioCorreo(correo) ? "Mensaje enviado. Gracias por contactarnos." : "Escribe un correo válido de @duoc.cl, @profesor.duoc.cl o @gmail.com.";
        mensaje.className = validarCorreo(correo) && validarDominioCorreo(correo) ? "mensaje correcto" : "mensaje error";
    });
}

function mostrarProductosAdmin() {
    let tabla = document.getElementById("tabla-productos");
    if (!tabla) return;
    let productos = obtenerProductos();
    tabla.innerHTML = "";
    for (let i = 0; i < productos.length; i++) {
        let producto = productos[i];
        let fila = tabla.insertRow();
        fila.innerHTML = "<td>" + producto.codigo + "</td><td>" + producto.nombre + "</td><td>" + formatoPrecio(producto.precio) + "</td><td>" + producto.stock + "</td><td>" + producto.critico + "</td><td>" + producto.categoria + "</td><td>" + (producto.stock <= producto.critico ? "<span class='stock-critico'>Stock crítico</span>" : "Stock normal") + "</td><td><a href='producto-form.html?codigo=" + producto.codigo + "'>Editar</a> <button type='button' data-eliminar-producto='" + producto.codigo + "'>Eliminar</button></td>";
    }
    let botones = document.querySelectorAll("[data-eliminar-producto]");
    for (let i = 0; i < botones.length; i++) {
        botones[i].addEventListener("click", function() {
            let codigo = botones[i].getAttribute("data-eliminar-producto");
            localStorage.setItem("productos", JSON.stringify(obtenerProductos().filter(function(item) { return item.codigo !== codigo; })));
            mostrarProductosAdmin();
        });
    }
}

function conectarFormularioProducto() {
    let formulario = document.getElementById("form-producto");
    if (!formulario) return;
    let codigoActual = new URLSearchParams(window.location.search).get("codigo");
    let productoActual = obtenerProductos().find(function(item) { return item.codigo === codigoActual; });
    if (productoActual) {
        for (let clave in productoActual) {
            let campo = formulario.elements[clave];
            if (campo) campo.value = productoActual[clave];
        }
    }
    formulario.addEventListener("submit", function(evento) {
        evento.preventDefault();
        let datos = new FormData(formulario);
        let producto = { codigo: datos.get("codigo"), id: datos.get("codigo").toLowerCase(), nombre: datos.get("nombre"), descripcion: datos.get("descripcion"), precio: Number(datos.get("precio")), stock: Number(datos.get("stock")), critico: Number(datos.get("critico")), categoria: datos.get("categoria"), imagen: datos.get("imagen") || "alimentos.svg" };
        if (producto.codigo.length < 3 || !producto.nombre || producto.nombre.length > 100 || producto.descripcion.length > 500 || producto.precio < 0 || !Number.isInteger(producto.stock) || producto.stock < 0 || (datos.get("critico") !== "" && (!Number.isInteger(producto.critico) || producto.critico < 0)) || !producto.categoria) {
            document.getElementById("mensaje-producto").textContent = "Completa los campos y revisa precio, stock y stock crítico.";
            return;
        }
        let productos = obtenerProductos();
        let posicion = productos.findIndex(function(item) { return item.codigo === producto.codigo; });
        if (posicion >= 0) productos[posicion] = producto; else productos.push(producto);
        localStorage.setItem("productos", JSON.stringify(productos));
        document.getElementById("mensaje-producto").textContent = "Producto guardado correctamente.";
    });
}

function mostrarUsuariosAdmin() {
    let tabla = document.getElementById("tabla-usuarios");
    if (!tabla) return;
    let usuarios = obtenerUsuarios();
    tabla.innerHTML = "";
    for (let i = 0; i < usuarios.length; i++) {
        let usuario = usuarios[i];
        let fila = tabla.insertRow();
        fila.innerHTML = "<td>" + usuario.run + "</td><td>" + usuario.nombre + " " + usuario.apellidos + "</td><td>" + usuario.correo + "</td><td>" + (usuario.tipo || "Cliente") + "</td><td>" + (usuario.region || "") + "</td><td>" + (usuario.comuna || "") + "</td><td><button type='button' data-eliminar-usuario='" + usuario.run + "'>Eliminar</button></td>";
    }
    let botones = document.querySelectorAll("[data-eliminar-usuario]");
    for (let i = 0; i < botones.length; i++) {
        botones[i].addEventListener("click", function() {
            let run = botones[i].getAttribute("data-eliminar-usuario");
            localStorage.setItem("usuarios", JSON.stringify(usuarios.filter(function(item) { return item.run !== run; })));
            mostrarUsuariosAdmin();
        });
    }
}

function conectarFormularioUsuario() {
    let formulario = document.getElementById("form-usuario");
    if (!formulario) return;
    formulario.addEventListener("submit", function(evento) {
        evento.preventDefault();
        let datos = new FormData(formulario);
        if (!validarRun(datos.get("run")) || !validarCorreo(datos.get("correo")) || !validarDominioCorreo(datos.get("correo"))) {
            document.getElementById("mensaje-usuario").textContent = "Revisa el RUN y el dominio del correo.";
            document.getElementById("mensaje-usuario").className = "mensaje error";
            return;
        }
        let usuarios = obtenerUsuarios();
        let usuarioExistente = usuarios.find(function(usuario) { return usuario.run === datos.get("run") || usuario.correo === datos.get("correo"); });
        if (usuarioExistente) {
            document.getElementById("mensaje-usuario").textContent = "El RUN o el correo ya están registrados.";
            document.getElementById("mensaje-usuario").className = "mensaje error";
            return;
        }
        usuarios.push(Object.fromEntries(datos.entries()));
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
        document.getElementById("mensaje-usuario").textContent = "Usuario guardado correctamente.";
        formulario.reset();
    });
}

document.addEventListener("DOMContentLoaded", function() {
    protegerAdministracion();
    obtenerProductos();
    obtenerUsuarios();
    mostrarProductosTienda();
    cargarDetalle();
    conectarFormularioRegistro();
    conectarFormularioLogin();
    conectarFormularioContacto();
    mostrarProductosAdmin();
    conectarFormularioProducto();
    mostrarUsuariosAdmin();
    conectarFormularioUsuario();
    conectarValidacionTiempoReal();
    let region = document.getElementById("region");
    if (region) {
        region.addEventListener("change", cargarComunas);
        cargarComunas();
    }
});